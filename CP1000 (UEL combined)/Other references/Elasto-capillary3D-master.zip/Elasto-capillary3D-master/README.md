# Elasto-capillary3D
Abaqus UEL and sample input files for modeling of elasto-capillary problems in 3D

# Cite
If used, please cite <a href="http://www.sciencedirect.com/science/article/pii/S2352431616301158">Yuhao Wang and David L. Henann. Finite-element modeling of soft solids with liquid inclusions. Extreme Mechanics Letters (2016) DOI:10.1016/j.eml.2016.06.002.</a>
